export class User{
    constructor(public id:number,public emailid:string="",public password:string=""){
        
    }
}
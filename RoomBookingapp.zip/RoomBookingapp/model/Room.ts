export class Room{
    constructor(public id:number,public name:string=""){
        
    }
}